# Coding-Ninjas-iPod-Mini-Project
**This is my project submission for the Coding Ninjas Web Developing course mini project which was a react app of iPod.** 

Which was Build an iPod using React.js. The following are the instructions:   Build a menu of options like you see such as Settings, Games, Music etc On clicking of the centre button go inside the menu Clicking on the menu should hide the menu and open a screen of that particular option, like settings, games etc Click and hold on the circular menu and move the mouse in a circular fashion inside the menu boundary (white circle is the menu) to navigate in the iPod menu Clicking on “Menu” should take you back to the main menu (Optionally) can create sub menu inside menu like in Music option, it has sub menu with options “All songs”, “Artists” etc.


A demo of the project - https://ninjasfiles.s3.amazonaws.com/0000000000003618.gif
